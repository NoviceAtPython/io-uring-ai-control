from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_event_projector_has_no_network_or_fleet_path_authority() -> None:
    unit = (ROOT / "deploy/systemd/iou-ai-event-projector.service").read_text(
        encoding="utf-8"
    )
    assert "PrivateNetwork=true" in unit
    assert "RestrictAddressFamilies=AF_UNIX" in unit
    assert "NoNewPrivileges=true" in unit
    assert "CapabilityBoundingSet=\n" in unit
    assert "ReadWritePaths=/var/lib/iou-ai/runtime /var/lib/iou-ai/events" in unit
    for forbidden in (
        "/root/fuzzer_workspace",
        "nat_out",
        "nat_seeds",
        "iou-fleet",
        "openai.key",
        "anthropic.key",
    ):
        assert forbidden not in unit


def test_shadow_service_deadline_exceeds_three_bounded_provider_calls() -> None:
    unit = (ROOT / "deploy/systemd/iou-ai-shadow.service").read_text(encoding="utf-8")
    assert "TimeoutStartSec=20min" in unit
    assert 3 * 300 < 20 * 60
    assert "KillSignal=SIGINT" in unit


def test_activation_does_not_enable_shadow_or_touch_production_fleet() -> None:
    script = (ROOT / "deploy/remote/activate-readonly.sh").read_text(encoding="utf-8")
    assert "iou-ai-shadow.timer" not in script
    assert "iou-ai-notify.timer" not in script
    assert "iou-ai-decision-import.timer" not in script
    for forbidden in ("systemctl stop iou-fleet", "nat_out", "nat_seeds"):
        assert forbidden not in script
    assert "iou-ai-event-projector.timer" not in script
    assert "systemctl start iou-ai-event-projector.service" not in script


def test_notifier_has_only_redacted_relay_authority() -> None:
    unit = (ROOT / "deploy/systemd/iou-ai-notify.service").read_text(
        encoding="utf-8"
    )
    assert "User=iou-ai-notify" in unit
    assert (
        "ExecStart=/opt/iou-ai/current/.venv/bin/iou-ai-notify run "
        "--events /var/lib/iou-ai/events "
        "--receipts /var/lib/iou-ai-notify/receipts "
        "--decision-inbox /var/lib/iou-ai-decisions/inbox "
        "--state-dir /var/lib/iou-ai-notify/state "
        "--endpoint-file /etc/iou-ai/relay-endpoint "
        "--token-file /run/credentials/iou-ai-notify.service/relay.token"
    ) in unit
    assert "LoadCredential=relay.token:/etc/iou-ai/credentials/relay.token" in unit
    assert "LoadCredential=relay.endpoint:" not in unit
    assert "ConditionFileNotEmpty=/etc/iou-ai/relay-endpoint" in unit
    assert "ConditionFileNotEmpty=/etc/iou-ai/credentials/relay.token" in unit
    assert "RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6" in unit
    assert (
        "ReadOnlyPaths=/opt/iou-ai /etc/iou-ai/relay-endpoint "
        "/var/lib/iou-ai/events"
    ) in unit
    assert (
        "ReadWritePaths=/var/lib/iou-ai-notify/receipts "
        "/var/lib/iou-ai-notify/state /var/lib/iou-ai-decisions/inbox"
    ) in unit
    assert unit.count("ReadWritePaths=") == 1
    assert "ProtectSystem=strict" in unit
    assert "NoNewPrivileges=true" in unit
    assert "CapabilityBoundingSet=\n" in unit
    inaccessible = next(
        line for line in unit.splitlines() if line.startswith("InaccessiblePaths=")
    )
    for forbidden in (
        "/etc/iou-ai/credentials",
        "/var/lib/iou-ai-decisions/archive",
        "/var/lib/iou-ai/quarantine",
        "/var/lib/iou-ai/contracts",
        "/var/lib/iou-ai/runtime",
        "/var/lib/iou-ai/inbox",
        "/var/lib/iou-ai/lkml",
        "/var/lib/iou-ai/export",
        "/var/lib/iou-ai-canary",
        "/opt/iou-ai-canary",
    ):
        assert forbidden in inaccessible
    for forbidden in (
        "openai.key",
        "anthropic.key",
        "decision.key",
        "/root/fuzzer_workspace",
        "nat_out",
        "nat_seeds",
        "iou-fleet",
    ):
        assert forbidden not in unit


def test_decision_importer_is_offline_and_cannot_execute() -> None:
    unit = (ROOT / "deploy/systemd/iou-ai-decision-import.service").read_text(
        encoding="utf-8"
    )
    assert "User=iou-ai-decision" in unit
    assert (
        "ExecStart=/opt/iou-ai/current/.venv/bin/iou-ai-decisions "
        "--events /var/lib/iou-ai/events "
        "--inbox /var/lib/iou-ai-decisions/inbox "
        "--archive /var/lib/iou-ai-decisions/archive "
        "--key-file "
        "/run/credentials/iou-ai-decision-import.service/decision.key"
    ) in unit
    assert "PrivateNetwork=true" in unit
    assert "RestrictAddressFamilies=AF_UNIX" in unit
    assert "AF_INET" not in unit
    assert "LoadCredential=decision.key:" in unit
    assert "ConditionFileNotEmpty=/etc/iou-ai/credentials/decision.key" in unit
    assert (
        "ReadOnlyPaths=/opt/iou-ai /var/lib/iou-ai/events "
        "/var/lib/iou-ai-decisions/inbox"
    ) in unit
    assert "ReadWritePaths=/var/lib/iou-ai-decisions/archive" in unit
    assert unit.count("ReadWritePaths=") == 1
    assert "ProtectSystem=strict" in unit
    assert "NoNewPrivileges=true" in unit
    assert "CapabilityBoundingSet=\n" in unit
    inaccessible = next(
        line for line in unit.splitlines() if line.startswith("InaccessiblePaths=")
    )
    for forbidden in (
        "/etc/iou-ai/credentials",
        "/var/lib/iou-ai-notify",
        "/var/lib/iou-ai/quarantine",
        "/var/lib/iou-ai/contracts",
        "/var/lib/iou-ai/runtime",
        "/var/lib/iou-ai/inbox",
        "/var/lib/iou-ai/lkml",
        "/var/lib/iou-ai/export",
        "/var/lib/iou-ai-canary",
        "/opt/iou-ai-canary",
    ):
        assert forbidden in inaccessible
    for forbidden in (
        "openai.key",
        "anthropic.key",
        "relay.token",
        "relay.endpoint",
        "/root/fuzzer_workspace",
        "nat_out",
        "nat_seeds",
        "iou-fleet",
    ):
        assert forbidden not in unit


def test_notification_units_are_installed_but_never_enabled() -> None:
    install = (ROOT / "deploy/remote/install.sh").read_text(encoding="utf-8")
    assert "install -d -o root -g iou-ai -m 0751 /var/lib/iou-ai" in install
    for unit in (
        "iou-ai-notify.service",
        "iou-ai-notify.timer",
        "iou-ai-decision-import.service",
        "iou-ai-decision-import.timer",
    ):
        assert unit in install
    assert "/etc/iou-ai/relay-endpoint" not in install
    for credential in ("relay.token", "decision.key"):
        assert f"/dev/null /etc/iou-ai/credentials/{credential}" not in install
    assert "systemctl enable" not in install
    assert "systemctl start" not in install


def test_notification_timers_require_explicit_operator_enablement() -> None:
    for name, service in (
        ("iou-ai-notify.timer", "iou-ai-notify.service"),
        ("iou-ai-decision-import.timer", "iou-ai-decision-import.service"),
    ):
        timer = (ROOT / "deploy/systemd" / name).read_text(encoding="utf-8")
        assert f"Unit={service}" in timer
        assert "WantedBy=timers.target" in timer

    activation = (ROOT / "deploy/remote/activate-readonly.sh").read_text(
        encoding="utf-8"
    )
    assert "iou-ai-notify" not in activation
    assert "iou-ai-decision-import" not in activation
