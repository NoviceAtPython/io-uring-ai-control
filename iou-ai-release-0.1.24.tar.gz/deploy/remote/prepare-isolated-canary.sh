#!/bin/sh
set -eu

# Build a root-owned, content-checked snapshot for the Nyx canary. This is a
# copy-only operation: it never starts a VM, invokes a fuzzer, writes an AFL
# queue, or signals a live worker. The runner consumes only this snapshot.
if [ "$(id -u)" -ne 0 ]; then
    echo "run with sudo" >&2
    exit 1
fi

SOURCE_ROOT=/root/fuzzer_workspace
RUNTIME=$SOURCE_ROOT/AFLplusplus
TARGET=$SOURCE_ROOT/nyx_targets/iou_native_kasan
RUNNER=/opt/iou-ai/current/deploy/remote/nyx_canary_oneshot.sh
PREFLIGHT=/home/saedyn/iou-ai-authority/canary-preflight.json
ROOT=/opt/iou-ai-canary
VERSIONS=$ROOT/versions
WORK_ROOT=/var/lib/iou-ai-canary/work
STAGE=$VERSIONS/.stage-$$

die() { echo "canary snapshot blocked: $*" >&2; exit 1; }
test -f "$PREFLIGHT" || die "read-only preflight is missing"
test -x "$RUNTIME/afl-cmin" || die "afl-cmin is missing"
test -x "$RUNTIME/afl-showmap" || die "afl-showmap is missing"
test -d "$RUNTIME/nyx_mode" || die "Nyx runtime directory is missing"
test -d "$TARGET" || die "KASAN target directory is missing"
test -f "$RUNNER" || die "canary runner is missing"

json_hash() {
    key=$1
    value=$(sed -n 's/.*"'"$key"'":"\([0-9a-f][0-9a-f]*\)".*/\1/p' "$PREFLIGHT")
    case "$value" in
        ????????????????????????????????????????????????????????????????) printf '%s\n' "$value" ;;
        *) die "preflight field $key is unavailable" ;;
    esac
}

current_hash() { sha256sum "$1" | awk '{print $1}'; }
test "$(json_hash afl_cmin_sha256)" = "$(current_hash "$RUNTIME/afl-cmin")" || die "afl-cmin changed since preflight"
test "$(json_hash runner_sha256)" = "$(current_hash "$RUNNER")" || die "runner changed since preflight"

tree_digest() {
    (
        cd "$1"
        {
            find . -xdev -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum
            find . -xdev -type l -printf 'link:%p:%l\n' | LC_ALL=C sort
        } | sha256sum | awk '{print $1}'
    )
}

runtime_digest() {
    (
        cd "$RUNTIME"
        {
            sha256sum ./afl-cmin ./afl-showmap
            find ./nyx_mode -xdev -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum
            find ./nyx_mode -xdev -type l -printf 'link:%p:%l\n' | LC_ALL=C sort
        } | sha256sum | awk '{print $1}'
    )
}

assert_internal_links() {
    root=$1
    find "$root" -xdev -type l -print | while IFS= read -r link; do
        resolved=$(readlink -f "$link") || die "snapshot symlink cannot be resolved"
        case "$resolved" in
            "$root"|"$root"/*) ;;
            *) die "snapshot symlink escapes its isolated root" ;;
        esac
    done
}

# A package-internal relative link is safe to copy as-is. Absolute links and
# links that escape their target/runtime root could reintroduce a reference to
# the live workspace, so they fail closed before and after the copy.
assert_internal_links "$TARGET"
assert_internal_links "$RUNTIME/nyx_mode"
test ! -L "$RUNTIME/afl-cmin" || die "afl-cmin is a symlink"
test ! -L "$RUNTIME/afl-showmap" || die "afl-showmap is a symlink"

target_before=$(tree_digest "$TARGET")
runtime_before=$(runtime_digest)
snapshot_id=$(printf '%s:%s\n' "$target_before" "$runtime_before" | sha256sum | awk '{print $1}')
destination=$VERSIONS/$snapshot_id
test ! -e "$destination" || die "identical snapshot already exists; refusing to overwrite it"

install -d -o root -g root -m 0755 "$VERSIONS"
install -d -o root -g root -m 0700 "$WORK_ROOT"
install -d -o root -g root -m 0700 "$STAGE/afl" "$STAGE/targets"
trap 'rm -rf "$STAGE"' EXIT HUP INT TERM
cp -a "$RUNTIME/afl-cmin" "$RUNTIME/afl-showmap" "$STAGE/afl/"
cp -a "$RUNTIME/nyx_mode" "$STAGE/afl/nyx_mode"
cp -a "$TARGET" "$STAGE/targets/iou_native_kasan"

assert_internal_links "$STAGE/targets/iou_native_kasan"
assert_internal_links "$STAGE/afl/nyx_mode"
test "$target_before" = "$(tree_digest "$TARGET")" || die "live target changed during copy"
test "$runtime_before" = "$(runtime_digest)" || die "Nyx runtime changed during copy"
test "$target_before" = "$(tree_digest "$STAGE/targets/iou_native_kasan")" || die "target copy digest mismatch"
(
    cd "$STAGE/afl"
    {
        sha256sum ./afl-cmin ./afl-showmap
        find ./nyx_mode -xdev -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum
        find ./nyx_mode -xdev -type l -printf 'link:%p:%l\n' | LC_ALL=C sort
    } | sha256sum | awk '{print $1}'
) | grep -qx "$runtime_before" || die "runtime copy digest mismatch"

printf '{"schema_version":"isolated-canary-snapshot.v1","snapshot_id":"%s","target_tree_sha256":"%s","runtime_tree_sha256":"%s","runner_sha256":"%s","source_live_fleet_modified":false}\n' \
    "$snapshot_id" "$target_before" "$runtime_before" "$(current_hash "$RUNNER")" \
    > "$STAGE/snapshot.json"
touch "$STAGE/.ready"
chown -R root:root "$STAGE"
chmod -R go-w "$STAGE"
find "$STAGE" -type d -exec chmod 0755 {} +
find "$STAGE" -type f -exec chmod a+r {} +
chmod 0755 "$STAGE/afl/afl-cmin" "$STAGE/afl/afl-showmap"
mv "$STAGE" "$destination"
ln -sfn "$destination" "$ROOT/current"
trap - EXIT HUP INT TERM
echo "prepared isolated Nyx canary snapshot: $destination"
